To generate docs, run "doxygen" in the incubator-singa/ directory

Doxygen >= 1.8 recommended
